//
//  ViewController.h
//  WebView
//
//  Created by Chris Serra on 10/4/13.
//  Copyright (c) 2013 Chris Serra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIWebView *viewWeb;

@end
